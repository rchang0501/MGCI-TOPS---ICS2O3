/*The Shopping Class
Ryan Chang
September 12, 2018
ICS203-03
Shopping
*/

// The "RC_Shopping" class.
import java.awt.*;
import hsa.Console;

public class RC_Shopping
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();
	c.print ("I am going ");
	c.println ("to the");
	c.println ("shopping mall.");
	c.println ();
	c.println ("There is no bus");
	c.print ("may I have a lift?");
    } // main method
} // RC_Shopping class
