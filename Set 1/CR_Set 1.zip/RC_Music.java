/*The Music Java Class
Ryan Chang
September 12, 2018
ICS203-03
Music
*/
// The "RC_Music" class.
import java.awt.*;
import hsa.Console;

public class RC_Music
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();
	c.println ("123456789012345");
	c.println ("  Rock and Roll");
	c.println ("      Metal    ");
	c.println ();
	c.println ("    The Blues  ");
	c.println();
	
    } // main method
} // RC_Music class
