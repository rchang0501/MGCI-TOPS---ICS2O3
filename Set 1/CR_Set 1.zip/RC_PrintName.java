/*The PrintName Java Class
Ryan Chang
September 12
ICS203-03
PrintName
Initial Starter Program*/

// The "RC_PrintName" class.
import java.awt.*;
import hsa.Console;

public class RC_PrintName
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	c.println ("My name is Ryan");
	c.println ("I am in grade 10");
	c.println ("I am from Marc Garneau C.I. for the TOPS program");
	c.println ("I am from North York, Ontario");
    } // main method
} // RC_PrintName class
